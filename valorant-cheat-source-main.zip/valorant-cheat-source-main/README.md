uploaded main.py file, check my newest github post.
join discord for support. https://discord.gg/Zumjamym
